export interface scrollDetailFace {
    deltaX: number,
    deltaY: number,
    scrollHeight: number,
    scrollLeft: number,
    scrollTop: number,
    scrollWidth:number,
}
export type statusType = "loading"|"error"|"success"|"never"