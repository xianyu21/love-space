export interface itemType {
    icon?: string,
    title?: string,
    content?: string
}