export interface listitem {
    text:number|string,
    id:number|string,
    [prop:string]:any
}